package com.alphalearning.myapplication1;

public class modelData {
    private String judulMovies;
    private String posterMovies;

    public String getJudulMovies() {
        return judulMovies;
    }

    public void setJudulMovies(String judulMovies) {
        this.judulMovies = judulMovies;
    }

    public String getPosterMovies() {
        return posterMovies;
    }

    public void setPosterMovies(String posterMovies) {
        this.posterMovies = posterMovies;
    }
}
