package com.alphalearning.myapplication1;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.alphalearning.myapplication1.model.ResultsItem;
import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

public class MoviesAdapter extends RecyclerView.Adapter<MoviesAdapter.MyViewHolder> {
    private Context context;
    private List<ResultsItem> adapterMovies = new ArrayList<>();

    public MoviesAdapter(Context context, List<ResultsItem> adapterMovies) {
        this.context = context;
        this.adapterMovies = adapterMovies;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemView = LayoutInflater.from(context).inflate(R.layout.item_movies, viewGroup, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, int i) {
        myViewHolder.tvJudul.setText(adapterMovies.get(i).getTitle());
        Glide.with(context).load("https://image.tmdb.org/t/p/w500" +adapterMovies.get(i).getPosterPath()).into(myViewHolder.ivPoster);

    }

    @Override
    public int getItemCount() {
        return adapterMovies.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tvJudul;
        ImageView ivPoster;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tvJudul = itemView.findViewById(R.id.tv_ItemMovies);
            ivPoster = itemView.findViewById(R.id.iv_ItemMovies);
        }
    }
}
