package com.alphalearning.myapplication1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import com.alphalearning.myapplication1.model.ResponseMovies;
import com.alphalearning.myapplication1.model.ResultsItem;

import com.alphalearning.myapplication1.retrofit.RetrofitConfig;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;


public class MainActivity extends AppCompatActivity {
    List<ResultsItem> dataMovie = new ArrayList<>();
    RecyclerView rvID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rvID = findViewById(R.id.rv_Id);
        //buat layout movies
//        //buat Model Data
//        modelData movies1 = new modelData();
//        movies1.setJudulMovies("judulMovies");
//        movies1.setPosterMovies("https://ecs7.tokopedia.net/img/cache/700/product-1/2019/5/23/23897862/23897862_b3f7a5a8-f0ed-4b7e-bf87-62deb3603eff_700_700");
//        for (int i = 0; i <20 ; i++) {
//            dataMovie.add(movies1);
//        }\
        getDataOnline();



        //buat adapter
        MoviesAdapter adapter = new MoviesAdapter(MainActivity.this, dataMovie);
        //buat layout grid
      //  rvID.setLayoutManager(new GridLayoutManager(MainActivity.this, 2));
        rvID.setLayoutManager(new LinearLayoutManager(MainActivity.this));
        rvID.setAdapter(adapter);

    }

    private void getDataOnline() {
        Call<ResponseMovies> request = RetrofitConfig.getApiService().ambilDataMovie("0dba618ff29f0045d49a78d2f5d2a314");
        request.enqueue(new Callback<ResponseMovies>() {
            @Override
            public void onResponse(Call<ResponseMovies> call, Response<ResponseMovies> response) {
                if (response.isSuccessful()) {
                    dataMovie = response.body().getResults();
                    MoviesAdapter adapter = new MoviesAdapter(MainActivity.this, dataMovie);
                    rvID.setAdapter(adapter);
                } else {
                    Toast.makeText(MainActivity.this, "Request Not Succses", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ResponseMovies> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Request FAilure", Toast.LENGTH_SHORT).show();

            }
        });
    }
}
